import React, { useState } from 'react';
import { 
  Map as MapIcon, 
  Mountain, 
  History, 
  Calendar, 
  ChevronRight, 
  Info, 
  Compass,
  Wine,
  Castle,
  Church,
  ExternalLink,
  Printer,
  Navigation,
  CheckCircle2,
  Download,
  MapPin,
  Star,
  BedDouble,
  Utensils,
  Sparkles,
  Mail,
  Globe,
  HelpCircle
} from 'lucide-react';

/* =========================================================
   ITINERARY TEMPLATE — copy this shape for each stage
   =========================================================
   hotel: { name, address, link, description }  — null = "Ask Kathy!"
   experiences: [{ title, description }]         — [] = "Ask Kathy!"
   restaurants: [{ name, description, link }]    — [] = "Ask Kathy!"
   ========================================================= */

const ROUTE_MAP = "https://www.google.com/maps/d/u/0/edit?mid=1m6MgV0QVg7yebyXiaJOplp3osHuKP0M&usp=sharing";

const ViaFrancigena = () => {
  const [activeDay, setActiveDay] = useState(1);

  const itinerary = [
    {
      day: 1,
      label: 'Arrival',
      route: "Arrival in San Miniato Alto",
      city: "San Miniato Alto",
      cityLink: "https://www.google.com/maps/search/?api=1&query=San+Miniato+Alto+Tuscany",
      cityDesc: "A spectacular hilltop town 50 km from Florence. Famous for its November white truffle fair, sweeping views over the Arno valley, and role as seat of the Holy Roman Emperor.",
      dist: "0 km",
      gain: "0m",
      loss: "0m",
      description: "Your travel will start from San Miniato, a jewel of Via Francigena. The Seminary, from which the main square takes its name, will surprise you with its particular façade: don't miss it illuminated, maybe after having enjoyed a risotto powdered with the typical white truffle, a local gastronomic pride.",
      history: "Known as the 'jewel' of the Via Francigena, this hilltop town is famous for its medieval Seminary and its prestigious white truffles.",
      hotel: {
        name: "Hotel San Miniato",
        address: "San Miniato, Tuscany",
        link: "https://www.google.com/maps/search/?api=1&query=Hotel+San+Miniato",
        description: "Your base for the first night in the hilltop jewel of the Via Francigena, within easy reach of the illuminated Seminary square and the town's famous truffle restaurants."
      },
      experiences: [
        { title: "White Truffle Evening", description: "See the Seminary square illuminated at dusk — if visiting in November, don't miss the International White Truffle Fair, one of Italy's most celebrated food events." },
        { title: "Rocca Tower Sunset", description: "Climb to the restored Rocca di Federico II for sweeping 360° views over the Arno valley and the Apennines — magical at golden hour." }
      ],
      restaurants: [
        { name: "Pepenero", description: "Michelin-selected modern Tuscan cuisine by Chef Gilberto Rossi. The white truffle menu (Oct–Dec) is unmissable. Piazza Duomo 4 — reserve ahead.", link: "https://www.pepenerocucina.it" }
      ],
      icon: <Church className="w-6 h-6" />,
      landmarks: [
        {
          name: "Piazza del Seminario",
          note: "Primary Sigeric stage · Key landmark",
          primary: true,
          link: "https://www.google.com/maps/search/?api=1&query=Piazza+del+Seminario+San+Miniato"
        },
        {
          name: "Rocca di Federico II",
          note: "Tower rebuilt by Napoleon — panoramic views",
          primary: false,
          link: "https://www.google.com/maps/search/?api=1&query=Rocca+Federico+II+San+Miniato"
        },
        {
          name: "Cattedrale di San Miniato",
          note: "Romanesque cathedral with stellar façade",
          primary: false,
          link: "https://www.google.com/maps/search/?api=1&query=Cattedrale+San+Miniato+Tuscany"
        }
      ]
    },
    {
      day: 2,
      label: 'Stage 1',
      route: "San Miniato to Gambassi Terme",
      city: "Gambassi Terme",
      cityLink: "https://www.google.com/maps/search/?api=1&query=Gambassi+Terme+Tuscany",
      cityDesc: "A spa town in the Val d'Elsa known for its therapeutic sulphurous waters. The public thermal baths are a perfect reward after 24 km of walking.",
      dist: "24 km",
      gain: "400m",
      loss: "220m",
      description: "From San Miniato, a paved road brings you to a spectacular route crossing the typical countryside of the Val d'Elsa. Following Sigeric's diary you meet two Submansiones: Pieve di Coiano (XXI, Sce Peter Currant) and Pieve a Chianni (XX, Sce Maria Glan), then you arrive at your accommodation.",
      history: "A significant trek through the Val d'Elsa. You'll pass Pieve di Coiano and Pieve a Chianni, both recorded by Sigeric in 990 AD.",
      hotel: {
        name: "Agriturismo Sant'Ilario — Superior Room",
        address: "Gambassi Terme, Tuscany",
        link: "https://www.google.com/maps/search/?api=1&query=Agriturismo+Sant'Ilario+Gambassi+Terme",
        description: "A rural farmhouse agriturismo in the Gambassi Terme countryside. Superior rooms offer comfort after a long day's walk, with locally produced food and a genuinely Tuscan atmosphere."
      },
      experiences: [
        { title: "Thermal Baths at Terme di Gambassi", description: "After 24 km on your feet, a soak in the therapeutic sulphurous waters of the Gambassi Terme spa is the perfect recovery. Book ahead as access can be limited." }
      ],
      restaurants: [],
      icon: <Wine className="w-6 h-6" />,
      landmarks: [
        {
          name: "Pieve di Coiano",
          note: "Sigeric stage XXXI · Recorded 990 AD",
          primary: true,
          link: "https://www.google.com/maps/search/?api=1&query=Pieve+di+Coiano+Castelfiorentino"
        },
        {
          name: "Pieve a Chianni",
          note: "Sigeric stage XXXII · Ancient Lombard church",
          primary: true,
          link: "https://www.google.com/maps/search/?api=1&query=Pieve+a+Chianni+Gambassi+Terme"
        },
        {
          name: "Terme di Gambassi",
          note: "Thermal spa — book ahead for tired legs",
          primary: false,
          link: "https://www.google.com/maps/search/?api=1&query=Terme+Gambassi+Terme+Tuscany"
        }
      ]
    },
    {
      day: 3,
      label: 'Stage 2',
      route: "Gambassi Terme to San Gimignano",
      city: "San Gimignano",
      cityLink: "https://www.google.com/maps/search/?api=1&query=San+Gimignano+Tuscany",
      cityDesc: "UNESCO World Heritage Site since 1990. Once had 72 towers — today 13 survive. Also celebrated for its Vernaccia di San Gimignano white wine, Italy's first DOC wine.",
      dist: "13.5 km",
      gain: "350m",
      loss: "350m",
      description: "Today you enjoy the wonderful surroundings of the Via Francigena. Before walking up to the peculiar villages of Collemuccioli and Pieve di Cellole, stop for a visit at the Sanctuary in Pancole. If you arrive early, take some time to visit the famous town of San Gimignano and enjoy its charming medieval atmosphere. Dinner is on your own in one of the many restaurants in town.",
      history: "Approaching the 'Manhattan of the Middle Ages'. This UNESCO site is world-renowned for its surviving 13 stone towers.",
      hotel: {
        name: "Hotel La Cisterna — Comfort Room",
        address: "Piazza della Cisterna 24, 53037 San Gimignano SI",
        link: "https://www.hotelcisterna.it",
        description: "A classic San Gimignano hotel right on the medieval Piazza della Cisterna, with stone-vaulted ceilings and views over the rooftops. Comfort rooms are spacious and beautifully appointed."
      },
      experiences: [
        { title: "Climb Torre Grossa", description: "The tallest surviving tower in San Gimignano (54 m) offers extraordinary views over the medieval rooftops and rolling Tuscan hills. Open daily — arrive early to beat the crowds." },
        { title: "Vernaccia Wine Tasting", description: "San Gimignano's Vernaccia was Italy's first DOC wine (1966). Visit one of the local cantinas for a tasting of this crisp, golden white wine paired with local pecorino." }
      ],
      restaurants: [
        { name: "Gelateria Dondoli", description: "World Gelato Champion Sergio Dondoli's shop on Piazza della Cisterna. Try the signature Crema di Santa Fina or Vernaccia Risotto flavour.", link: "https://www.gelateriasangimignano.com" },
        { name: "Cum Quibus", description: "Refined modern Tuscan cuisine in a stone-vaulted dining room. Local seasonal produce, excellent wine list. Reservations essential.", link: "https://www.google.com/maps/search/?api=1&query=Cum+Quibus+San+Gimignano" }
      ],
      icon: <Castle className="w-6 h-6" />,
      landmarks: [
        {
          name: "Santuario della Madonna di Pancole",
          note: "Sigeric waypoint · Pilgrimage chapel en route",
          primary: true,
          link: "https://www.google.com/maps/search/?api=1&query=Santuario+Madonna+Pancole+San+Gimignano"
        },
        {
          name: "Le 13 Torri di San Gimignano",
          note: "UNESCO icon — climb Torre Grossa for views",
          primary: true,
          link: "https://www.google.com/maps/search/?api=1&query=Torre+Grossa+San+Gimignano"
        },
        {
          name: "Collegiata di Santa Maria Assunta",
          note: "Romanesque church with Ghirlandaio frescoes",
          primary: false,
          link: "https://www.google.com/maps/search/?api=1&query=Collegiata+Santa+Maria+Assunta+San+Gimignano"
        }
      ]
    },
    {
      day: 4,
      label: 'Stage 3',
      route: "San Gimignano to Colle Val d'Elsa",
      city: "Colle di Val d'Elsa",
      cityLink: "https://www.google.com/maps/search/?api=1&query=Colle+di+Val+d'Elsa+Siena",
      cityDesc: "A medieval upper town (Colle Alta) perched on a ridge, birthplace of the architect Arnolfo di Cambio. The lower town is world-renowned for its crystal glasswork — over 15% of world crystal production.",
      dist: "12 km",
      gain: "270m",
      loss: "380m",
      description: "Today you walk a gorgeous path of the Via Francigena. Going up and down the Tuscan hills, crossing vineyards, olive groves, fields and woods, you finally reach your accommodation in Colle di Val d'Elsa. Along the way, you can make a detour to discover the fascinating Abbey of Santa Maria a Conero of the XI century.",
      history: "A stunning path through classic Tuscan landscapes: vineyards, olive groves, and the XI-century Abbey of Santa Maria a Conero.",
      hotel: {
        name: "Hotel Palazzo San Lorenzo",
        address: "Colle di Val d'Elsa, Tuscany",
        link: "https://www.google.com/maps/search/?api=1&query=Hotel+Palazzo+San+Lorenzo+Colle+Val+d'Elsa",
        description: "An elegant palazzo hotel in the historic centre of Colle di Val d'Elsa, close to the medieval upper town. A refined stop between San Gimignano and Monteriggioni."
      },
      experiences: [
        { title: "Museo del Cristallo", description: "Colle Val d'Elsa produces over 15% of the world's crystal. This engaging museum traces the history of crystal-making from ancient Venice to the present. Entrance fee applies." },
        { title: "Walk Colle Alta", description: "The upper medieval town (Colle Alta) is linked to the lower town by a funicular. Stroll the Via del Castello — birthplace of architect Arnolfo di Cambio, who designed Florence Cathedral." }
      ],
      restaurants: [],
      icon: <Compass className="w-6 h-6" />,
      landmarks: [
        {
          name: "Abbazia di Santa Maria a Conero",
          note: "XI-century abbey · Key waypoint on the route",
          primary: true,
          link: "https://www.google.com/maps/search/?api=1&query=Abbazia+Santa+Maria+Coneo+Colle+Val+Elsa"
        },
        {
          name: "Colle Alta — Medieval Upper Town",
          note: "Birthplace of Arnolfo di Cambio (designer of Florence Cathedral)",
          primary: true,
          link: "https://www.google.com/maps/search/?api=1&query=Colle+Alta+Colle+di+Val+d'Elsa"
        },
        {
          name: "Museo del Cristallo",
          note: "Crystal glass museum in the lower town",
          primary: false,
          link: "https://www.google.com/maps/search/?api=1&query=Museo+Cristallo+Colle+Val+Elsa"
        }
      ]
    },
    {
      day: 5,
      label: 'Stage 4',
      route: "Colle Val d'Elsa to Monteriggioni",
      city: "Monteriggioni",
      cityLink: "https://www.google.com/maps/search/?api=1&query=Monteriggioni+Siena",
      cityDesc: "One of Tuscany's best-preserved medieval villages. Built by Siena in 1213 as a military fortress, its perfectly circular walls with 14 towers inspired Dante's vision of Hell's giants in the Inferno.",
      dist: "11-15 km",
      gain: "175-250m",
      loss: "110-190m",
      description: "From Colle, cross Pieve a Elsa and meet the ancient Etruscan Thermae (hot pool) of Caldane. After reaching Strove and its beautiful Romanesque Church, continue walking along the particular complex of Abbadia a Isola till you reach the medieval town of Monteriggioni, surrounded by its peculiar crown of towers.",
      history: "The route leads to the iconic circular fortress of Monteriggioni, whose 'crown' of towers was so striking it was mentioned in Dante's Inferno.",
      hotel: {
        name: "Hotel Monteriggioni",
        address: "Via 1 Maggio 4, 53035 Monteriggioni SI",
        link: "https://www.hotelmonteriggioni.net",
        description: "Peaceful 4-star hotel set in a restored villa just outside the fortress walls, with gardens, pool, and easy walking distance into the medieval village. An atmospheric way to experience Monteriggioni."
      },
      experiences: [
        { title: "Walk the Fortress Walls at Sunset", description: "The 570-metre circuit of walls with 14 towers can be walked in under an hour. At dusk, the surrounding Tuscan countryside glows golden — one of the most romantic views on the whole route." },
        { title: "Abbadia a Isola", description: "An 11th-century Benedictine monastery en route, now partially inhabited. The Romanesque church retains original frescoes and a remarkable carved stone tabernacle." }
      ],
      restaurants: [],
      icon: <Castle className="w-6 h-6" />,
      landmarks: [
        {
          name: "Mura di Monteriggioni",
          note: "Dante's Inferno, Canto XXXI — 'Di torre fortissime cimata'",
          primary: true,
          link: "https://www.google.com/maps/search/?api=1&query=Mura+Monteriggioni+fortress+walls"
        },
        {
          name: "Chiesa di Santa Maria Assunta",
          note: "Romanesque church inside the fortress walls",
          primary: false,
          link: "https://www.google.com/maps/search/?api=1&query=Chiesa+Santa+Maria+Assunta+Monteriggioni"
        }
      ]
    },
    {
      day: 6,
      label: 'Stage 5',
      route: "Monteriggioni to Siena",
      city: "Siena",
      cityLink: "https://www.google.com/maps/search/?api=1&query=Siena+city+centre+Italy",
      cityDesc: "A UNESCO World Heritage city, rival to Florence during the Middle Ages. Home to the Palio horse race (held twice yearly in Piazza del Campo), an astounding Gothic Duomo, and the Monte dei Paschi — the world's oldest bank.",
      dist: "20 km",
      gain: "300m",
      loss: "250m",
      description: "Leaving Monteriggioni, you walk on dirt roads along the Montagnola Senese, the main hilly area in the district. You pass the ancient medieval suburb of Cerbaia, which appears currently abandoned. Across the wood you reach the Castle of Chiocciola and go up to Poggio di Riciano. Descend to the old river of Pian del Lago, then at the end of the Renai forest enter the beautiful town of Siena through the ancient pilgrim's gate of Porta Camollia.",
      history: "Entering Siena through the traditional Porta Camollia. The trek concludes in the magnificent Piazza del Campo.",
      hotel: {
        name: "Hotel Athena — Deluxe Room",
        address: "Via Paolo Mascagni 55, 53100 Siena SI",
        link: "https://www.hotelathena.com",
        description: "A stylish 4-star hotel with a rooftop terrace offering stunning views over the Siena skyline. Deluxe rooms are spacious and contemporary — the perfect reward for completing your pilgrimage."
      },
      experiences: [
        { title: "Piazza del Campo at Golden Hour", description: "The shell-shaped Campo is the beating heart of Siena. Arrive at the Fonte Gaia fountain as the sun sets behind the Torre del Mangia and enjoy a well-earned Aperol Spritz at one of the piazza cafes." },
        { title: "Duomo di Siena Interior", description: "One of Italy's greatest Gothic cathedrals — the striped marble interior, Nicola Pisano's pulpit, and the Piccolomini Library's Pinturicchio frescoes are not to be missed. Book the combined museum ticket." }
      ],
      restaurants: [
        { name: "Osteria Le Logge", description: "A Sienese institution set inside a beautifully preserved 19th-century pharmacy. Perfect for a celebration last dinner — try the pici al ragù and the local Brunello. Via del Porrione 33.", link: "https://www.google.com/maps/search/?api=1&query=Osteria+Le+Logge+Siena" }
      ],
      icon: <Church className="w-6 h-6" />,
      landmarks: [
        {
          name: "Piazza del Campo",
          note: "Sigeric final stage · One of Europe's greatest medieval squares",
          primary: true,
          link: "https://www.google.com/maps/search/?api=1&query=Piazza+del+Campo+Siena"
        },
        {
          name: "Porta Camollia",
          note: "Traditional pilgrim entrance to Siena",
          primary: true,
          link: "https://www.google.com/maps/search/?api=1&query=Porta+Camollia+Siena"
        },
        {
          name: "Duomo di Siena",
          note: "Extraordinary Gothic cathedral with Pisano pulpit",
          primary: false,
          link: "https://www.google.com/maps/search/?api=1&query=Duomo+Siena+Cathedral"
        },
        {
          name: "Palazzo Pubblico & Torre del Mangia",
          note: "Gothic civic palace — climb the tower for panoramic views",
          primary: false,
          link: "https://www.google.com/maps/search/?api=1&query=Palazzo+Pubblico+Torre+Mangia+Siena"
        }
      ]
    }
  ];

  const handleKmlDownload = async () => {
    const response = await fetch('/via-francigena-route.kml');
    const text = await response.text();
    const blob = new Blob([text], { type: 'application/vnd.google-earth.kml+xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'via-francigena-route.kml';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-[#fcfaf7] font-sans text-slate-900 p-4 md:p-8">
      {/* Header section */}
      <header className="max-w-6xl mx-auto mb-10 text-center relative">
        <div className="flex justify-between items-start mb-4">
          <div className="w-10"></div>
          <div className="flex flex-col items-center">
             <span className="text-amber-600 font-bold tracking-[0.2em] text-xs uppercase mb-2">Tuscany 2026</span>
             <h1 className="text-4xl md:text-6xl font-serif font-black text-amber-950 tracking-tight">
               Via Francigena
             </h1>
          </div>
          <button 
            onClick={() => window.print()}
            className="print:hidden p-3 bg-white border border-amber-100 rounded-full shadow-sm hover:shadow-md transition-shadow text-amber-700"
            title="Save as PDF"
          >
            <Printer size={20} />
          </button>
        </div>
        
        <p className="text-xl text-amber-800/80 font-serif italic mb-8">The Heart of the Pilgrim's Way: San Miniato to Siena</p>
        
        <div className="flex flex-wrap justify-center gap-4">
          <div className="bg-white px-5 py-3 rounded-2xl shadow-sm border border-amber-100 flex items-center gap-3">
            <Calendar className="text-amber-600" size={20} />
            <div className="text-left">
              <p className="text-[10px] text-slate-400 uppercase font-black tracking-widest leading-none mb-1">Duration</p>
              <p className="font-bold text-slate-700">6 Days</p>
            </div>
          </div>
          <div className="bg-white px-5 py-3 rounded-2xl shadow-sm border border-amber-100 flex items-center gap-3">
            <Compass className="text-amber-600" size={20} />
            <div className="text-left">
              <p className="text-[10px] text-slate-400 uppercase font-black tracking-widest leading-none mb-1">Distance</p>
              <p className="font-bold text-slate-700">84.5 km</p>
            </div>
          </div>
          <div className="bg-white px-5 py-3 rounded-2xl shadow-sm border border-amber-100 flex items-center gap-3">
            <Mountain className="text-amber-600" size={20} />
            <div className="text-left">
              <p className="text-[10px] text-slate-400 uppercase font-black tracking-widest leading-none mb-1">Total Ascent</p>
              <p className="font-bold text-slate-700">1,495 m</p>
            </div>
          </div>
          <a
            href={ROUTE_MAP}
            target="_blank"
            rel="noopener noreferrer"
            className="print:hidden bg-amber-600 text-white px-5 py-3 rounded-2xl shadow-sm border border-amber-500 flex items-center gap-3 hover:bg-amber-700 transition-colors"
            title="Open full route on Google Maps"
          >
            <Navigation className="text-amber-100" size={20} />
            <div className="text-left">
              <p className="text-[10px] text-amber-100 uppercase font-black tracking-widest leading-none mb-1">Full Route</p>
              <p className="font-bold text-white">Route on Google Maps</p>
            </div>
          </a>
          <button
            onClick={handleKmlDownload}
            className="print:hidden bg-amber-950 text-amber-50 px-5 py-3 rounded-2xl shadow-sm border border-amber-800 flex items-center gap-3 hover:bg-amber-900 transition-colors"
            title="Download KML for Google Maps"
          >
            <Download className="text-amber-300" size={20} />
            <div className="text-left">
              <p className="text-[10px] text-amber-300 uppercase font-black tracking-widest leading-none mb-1">Google Earth / Maps</p>
              <p className="font-bold text-amber-50">Download KML</p>
            </div>
          </button>
        </div>
      </header>

      {/* ── Route Visualization ── */}
      <div className="max-w-6xl mx-auto mb-10 print:hidden">
        <div className="bg-amber-950 rounded-[2.5rem] p-1 shadow-2xl shadow-amber-950/20 relative overflow-hidden">
          <div className="bg-[#fdf9f0] rounded-[calc(2.5rem-4px)] px-10 pt-8 pb-12 relative">
            <div className="absolute inset-0 opacity-10 pointer-events-none rounded-[calc(2.5rem-4px)]" style={{backgroundImage: "url('https://www.transparenttextures.com/patterns/parchment.png')"}}></div>
            <div className="flex justify-between items-center mb-8">
              <h3 className="font-serif italic text-2xl text-amber-900">Path through the Heart of Tuscany</h3>
              <div className="text-[10px] font-black uppercase tracking-widest text-amber-700/50">San Miniato ➔ Siena</div>
            </div>
            <div className="relative flex justify-between items-center px-12 h-28">
              <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 800 200" preserveAspectRatio="none">
                <path
                  d="M 50,100 C 150,40 250,160 350,100 S 550,40 750,100"
                  fill="none"
                  stroke="#b45309"
                  strokeWidth="3"
                  strokeDasharray="10 10"
                  strokeLinecap="round"
                  className="opacity-40"
                />
              </svg>
              {itinerary.map((d, i) => (
                <div
                  key={i}
                  className={`relative z-10 p-3 rounded-full border-4 transition-all duration-500 cursor-pointer group ${activeDay === d.day ? 'bg-amber-600 border-amber-950 scale-125 shadow-xl' : 'bg-white border-amber-200 hover:border-amber-400'}`}
                  onClick={() => setActiveDay(d.day)}
                >
                  {React.cloneElement(d.icon, {
                    className: `w-6 h-6 ${activeDay === d.day ? 'text-white' : 'text-amber-800'}`
                  })}
                  <div className={`absolute -bottom-8 left-1/2 -translate-x-1/2 whitespace-nowrap text-[9px] font-black uppercase tracking-tighter transition-opacity duration-300 ${activeDay === d.day ? 'opacity-100 text-amber-900' : 'opacity-0 group-hover:opacity-100 text-amber-700'}`}>
                    {d.route.split(' ').pop()}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Print-only: all 6 stages stacked */}
      <div className="hidden print:block max-w-4xl mx-auto mb-12 space-y-8">
        {itinerary.map((step) => (
          <div key={step.day} className="border border-amber-200 rounded-2xl p-8 relative overflow-hidden break-inside-avoid">
            <div className="absolute -top-6 -right-6 opacity-[0.04] text-amber-900 pointer-events-none rotate-12">
              {React.cloneElement(step.icon, { size: 160 })}
            </div>
            <div className="relative z-10">
              <div className="flex items-center justify-between mb-4">
                <span className="text-[10px] font-black px-3 py-1 rounded-full bg-amber-900 text-amber-100 tracking-widest">
                  {step.label.toUpperCase()}
                </span>
                <div className="flex gap-3">
                  <span className="text-xs font-black text-amber-700 bg-amber-50 border border-amber-100 px-3 py-1 rounded-full">
                    CLIMB: +{step.gain}
                  </span>
                  <span className="text-xs font-black text-slate-600 bg-slate-50 border border-slate-200 px-3 py-1 rounded-full">
                    {step.dist}
                  </span>
                </div>
              </div>
              <h3 className="text-2xl font-serif font-black text-amber-950 mb-6">{step.route}</h3>
              <div className="grid grid-cols-2 gap-8">
                <div>
                  <p className="text-[10px] font-black uppercase tracking-widest text-amber-700 mb-2 flex items-center gap-1">
                    <History size={12} /> Historical Significance
                  </p>
                  <p className="text-slate-600 font-serif italic text-base leading-relaxed border-l-4 border-amber-200 pl-4 mb-4">
                    {step.history}
                  </p>
                  <div className="flex items-start gap-2 p-3 bg-slate-50 border border-slate-200 rounded-xl">
                    <MapPin size={13} className="text-amber-600 mt-0.5 shrink-0" />
                    <div>
                      <p className="font-black text-slate-700 text-xs">{step.city}</p>
                      <p className="text-[10px] text-slate-500 leading-snug mt-0.5">{step.cityDesc}</p>
                    </div>
                  </div>
                </div>
                <div>
                  <p className="text-[10px] font-black uppercase tracking-widest text-amber-700 mb-2 flex items-center gap-1">
                    <Info size={12} /> Landmarks
                  </p>
                  <div className="space-y-2">
                    {step.landmarks.map((lm, li) => (
                      <div key={li} className={`p-3 rounded-xl border text-xs ${lm.primary ? 'bg-amber-50 border-amber-200' : 'bg-white border-slate-100'}`}>
                        <div className="flex items-center gap-1 mb-0.5">
                          {lm.primary ? <Star size={10} className="text-amber-600 shrink-0" /> : <MapPin size={10} className="text-slate-400 shrink-0" />}
                          <p className={`font-black ${lm.primary ? 'text-amber-950' : 'text-slate-700'}`}>{lm.name}</p>
                        </div>
                        <p className="text-[10px] text-slate-500 pl-4">{lm.note}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <main className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 mb-12 print:hidden">
        
        {/* Left Column: Explorer */}
        <div className="lg:col-span-4 space-y-3">
          <h2 className="text-lg font-black uppercase tracking-widest text-slate-400 flex items-center gap-2 mb-4 px-2">
            <MapIcon size={18} className="text-amber-600" />
            Stages
          </h2>
          {itinerary.map((step) => (
            <button
              key={step.day}
              onClick={() => setActiveDay(step.day)}
              className={`w-full text-left p-4 rounded-2xl transition-all duration-300 border-2 ${
                activeDay === step.day 
                ? 'bg-amber-900 text-white shadow-xl border-amber-900 translate-x-2' 
                : 'bg-white hover:bg-amber-50 border-white hover:border-amber-100 text-slate-600'
              }`}
            >
              <div className="flex justify-between items-center mb-1">
                <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${activeDay === step.day ? 'bg-amber-700 text-amber-100' : 'bg-slate-100 text-slate-500'}`}>
                  {step.label.toUpperCase()}
                </span>
                <span className="text-[11px] font-mono opacity-60">{step.dist}</span>
              </div>
              <p className="font-bold leading-tight">{step.route}</p>
            </button>
          ))}
        </div>

        {/* Right Column: Content Card */}
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-white rounded-[2rem] p-8 shadow-2xl shadow-amber-900/5 border border-amber-100 relative overflow-hidden min-h-[350px]">
            {/* Watermark Icon */}
            <div className="absolute -top-10 -right-10 opacity-[0.03] text-amber-900 pointer-events-none transform rotate-12">
              {React.cloneElement(itinerary[activeDay - 1].icon, { size: 300 })}
            </div>
            
            <div className="relative z-10">
              <div className="mb-6">
                <span className="text-amber-600 font-black text-xs uppercase tracking-[0.2em]">{itinerary[activeDay - 1].label}</span>
                <h3 className="text-3xl md:text-4xl font-serif font-black text-amber-950 mt-1">
                  {itinerary[activeDay - 1].route}
                </h3>
              </div>

              <div className="flex gap-3 mb-6">
                <div className="bg-amber-50 text-amber-900 px-4 py-1.5 rounded-full text-xs font-black flex items-center gap-2 border border-amber-100">
                  <Mountain size={14} className="text-amber-600"/> CLIMB: +{itinerary[activeDay - 1].gain}
                </div>
                <div className="bg-slate-50 text-slate-600 px-4 py-1.5 rounded-full text-xs font-black flex items-center gap-2 border border-slate-200">
                  <ChevronRight size={14} className="text-slate-400"/> DISTANCE: {itinerary[activeDay - 1].dist}
                </div>
              </div>

              {/* Walking description */}
              <div className="mb-8 p-5 bg-[#fdf9f0] border border-amber-100 rounded-2xl">
                <div className="flex items-center gap-2 text-amber-700 font-black uppercase text-xs tracking-widest mb-3">
                  <Navigation size={15} /> Today's Walk
                </div>
                <p className="text-slate-700 leading-relaxed text-base">
                  {itinerary[activeDay - 1].description}
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-10">
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-amber-700 font-black uppercase text-xs tracking-widest">
                    <History size={16} /> Historical Significance
                  </div>
                  <p className="text-slate-600 leading-relaxed font-serif text-lg italic border-l-4 border-amber-200 pl-6 py-2">
                    {itinerary[activeDay - 1].history}
                  </p>
                  {/* City highlight */}
                  <a
                    href={itinerary[activeDay - 1].cityLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-start gap-3 p-4 bg-amber-50 border border-amber-200 rounded-2xl hover:border-amber-400 hover:bg-amber-100 transition-all group"
                  >
                    <MapPin size={16} className="text-amber-600 mt-0.5 shrink-0" />
                    <div>
                      <p className="font-black text-amber-700 text-base group-hover:text-amber-900 transition-colors underline underline-offset-2">{itinerary[activeDay - 1].city}</p>
                      <p className="text-sm text-slate-600 leading-relaxed mt-0.5">{itinerary[activeDay - 1].cityDesc}</p>
                    </div>
                    <ExternalLink size={12} className="text-amber-500 shrink-0 mt-0.5" />
                  </a>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-amber-700 font-black uppercase text-xs tracking-widest">
                    <Info size={16} /> Landmarks & Points of Interest
                  </div>
                  {itinerary[activeDay - 1].landmarks.map((lm, i) => (
                    <a
                      key={i}
                      href={lm.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`flex items-start gap-3 p-4 rounded-2xl border transition-all group ${
                        lm.primary
                          ? 'bg-gradient-to-br from-amber-50 to-orange-50 border-amber-200 hover:border-amber-400 hover:shadow-md'
                          : 'bg-white border-slate-100 hover:border-amber-100 hover:bg-amber-50'
                      }`}
                    >
                      {lm.primary
                        ? <Star size={14} className="text-amber-500 mt-0.5 shrink-0" />
                        : <MapPin size={14} className="text-amber-400 mt-0.5 shrink-0" />
                      }
                      <div className="flex-1 min-w-0">
                        <p className="font-black text-base leading-tight text-amber-600 underline underline-offset-2 group-hover:text-amber-800 transition-colors">{lm.name}</p>
                        <p className="text-sm text-slate-500 mt-0.5 leading-snug">{lm.note}</p>
                      </div>
                      <ExternalLink size={11} className="text-amber-400 shrink-0 mt-0.5" />
                    </a>
                  ))}
                </div>
              </div>

              {/* ── Hotel ─────────────────────────────── */}
              <div className="mt-8 -mx-8 px-8 py-6 bg-amber-50 border-t-4 border-amber-400">
                <div className="flex items-center gap-2 text-amber-700 font-black uppercase text-xs tracking-widest mb-3">
                  <BedDouble size={15} /> Tonight's Stay
                </div>
                {itinerary[activeDay - 1].hotel ? (
                  <a
                    href={itinerary[activeDay - 1].hotel.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-start gap-4 p-4 bg-white border-2 border-amber-200 rounded-2xl hover:border-amber-400 hover:shadow-md transition-all group"
                  >
                    <BedDouble size={20} className="text-amber-500 mt-0.5 shrink-0" />
                    <div className="flex-1">
                      <p className="font-black text-amber-700 underline underline-offset-2 group-hover:text-amber-900 transition-colors">{itinerary[activeDay - 1].hotel.name}</p>
                      <p className="text-xs text-slate-500 mt-0.5 mb-1">{itinerary[activeDay - 1].hotel.address}</p>
                      <p className="text-sm text-slate-600 leading-relaxed">{itinerary[activeDay - 1].hotel.description}</p>
                    </div>
                    <ExternalLink size={12} className="text-amber-400 shrink-0 mt-0.5" />
                  </a>
                ) : (
                  <div className="flex items-center gap-3 p-4 bg-white border border-dashed border-amber-300 rounded-2xl">
                    <HelpCircle size={18} className="text-amber-500 shrink-0" />
                    <div>
                      <p className="font-black text-amber-700 text-sm">Ask Kathy!</p>
                      <p className="text-sm text-slate-500">Hotel recommendation coming — contact <a href="mailto:kathy.dragon@wholejourneys.com" className="text-amber-600 underline">kathy.dragon@wholejourneys.com</a></p>
                    </div>
                  </div>
                )}
              </div>

              {/* ── Suggested Experiences ─────────────── */}
              <div className="mt-6 border-t border-amber-100 pt-6">
                <div className="flex items-center gap-2 text-amber-700 font-black uppercase text-xs tracking-widest mb-3">
                  <Sparkles size={15} /> Suggested Experiences
                </div>
                {itinerary[activeDay - 1].experiences.length > 0 ? (
                  <div className="grid md:grid-cols-2 gap-3">
                    {itinerary[activeDay - 1].experiences.map((exp, i) => (
                      <div key={i} className="p-4 bg-gradient-to-br from-orange-50 to-amber-50 border border-amber-100 rounded-2xl">
                        <p className="font-black text-amber-900 text-base mb-1 flex items-center gap-1.5"><Sparkles size={13} className="text-amber-500" />{exp.title}</p>
                        <p className="text-sm text-slate-600 leading-relaxed">{exp.description}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="flex items-center gap-3 p-4 bg-amber-50 border border-dashed border-amber-300 rounded-2xl">
                    <HelpCircle size={18} className="text-amber-500 shrink-0" />
                    <div>
                      <p className="font-black text-amber-700 text-sm">Ask Kathy!</p>
                      <p className="text-sm text-slate-500">Experience suggestions coming — contact <a href="mailto:kathy.dragon@wholejourneys.com" className="text-amber-600 underline">kathy.dragon@wholejourneys.com</a></p>
                    </div>
                  </div>
                )}
              </div>

              {/* ── Restaurants & Tastes ──────────────── */}
              <div className="mt-6 border-t border-amber-100 pt-6">
                <div className="flex items-center gap-2 text-amber-700 font-black uppercase text-xs tracking-widest mb-3">
                  <Utensils size={15} /> Restaurants & Local Tastes
                </div>
                {itinerary[activeDay - 1].restaurants.length > 0 ? (
                  <div className="grid md:grid-cols-2 gap-3">
                    {itinerary[activeDay - 1].restaurants.map((r, i) => (
                      <a
                        key={i}
                        href={r.link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-start gap-3 p-4 bg-white border border-slate-100 rounded-2xl hover:border-amber-200 hover:bg-amber-50 transition-all group"
                      >
                        <Utensils size={14} className="text-amber-400 mt-0.5 shrink-0" />
                        <div className="flex-1">
                          <p className="font-black text-amber-600 underline underline-offset-2 group-hover:text-amber-800 text-base transition-colors">{r.name}</p>
                          <p className="text-sm text-slate-500 mt-0.5 leading-relaxed">{r.description}</p>
                        </div>
                        <ExternalLink size={11} className="text-amber-400 shrink-0 mt-0.5" />
                      </a>
                    ))}
                  </div>
                ) : (
                  <div className="flex items-center gap-3 p-4 bg-amber-50 border border-dashed border-amber-300 rounded-2xl">
                    <HelpCircle size={18} className="text-amber-500 shrink-0" />
                    <div>
                      <p className="font-black text-amber-700 text-sm">Ask Kathy!</p>
                      <p className="text-sm text-slate-500">Restaurant picks coming — contact <a href="mailto:kathy.dragon@wholejourneys.com" className="text-amber-600 underline">kathy.dragon@wholejourneys.com</a></p>
                    </div>
                  </div>
                )}
              </div>

            </div>
          </div>

        </div>
      </main>

      <footer className="max-w-6xl mx-auto border-t border-amber-100 pt-10 pb-16 print:hidden">
        <div className="flex flex-col md:flex-row justify-between items-start gap-8 mb-8">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-amber-50 rounded-2xl">
              <History size={20} className="text-amber-600" />
            </div>
            <div>
              <p className="text-xs font-black uppercase tracking-widest text-slate-500">Historical Reference</p>
              <p className="text-sm font-serif italic text-slate-400">Archbishop Sigeric of Canterbury, AD 994</p>
            </div>
          </div>
          <div className="flex items-center gap-6">
            <button
              onClick={handleKmlDownload}
              className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.2em] text-amber-700/80 hover:text-amber-700 transition-colors"
            >
              <Download size={14} />
              KML for Google Maps
            </button>
            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-amber-700/60">UNESCO Heritage Protected</span>
            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-amber-700/60">Official Pilgrim Route</span>
          </div>
        </div>

        {/* Infographics nav link */}
        <div className="border-t border-amber-100 pt-4 pb-2 flex justify-center">
          <a href="/" className="text-[11px] font-black uppercase tracking-widest text-amber-500 hover:text-amber-700 transition-colors">
            ← Infographics
          </a>
        </div>

        {/* Designer credit */}
        <div className="border-t border-amber-100 pt-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-slate-400 font-serif italic">
            Iconographic designed by <span className="font-black text-amber-700">Kathy Dragon</span>, Whole Journeys
          </p>
          <div className="flex items-center gap-5">
            <a
              href="mailto:kathy.dragon@wholejourneys.com"
              className="flex items-center gap-1.5 text-[11px] font-black uppercase tracking-widest text-amber-600 hover:text-amber-800 transition-colors"
            >
              <Mail size={13} />
              kathy.dragon@wholejourneys.com
            </a>
            <a
              href="https://www.wholejourneys.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 text-[11px] font-black uppercase tracking-widest text-amber-600 hover:text-amber-800 transition-colors"
            >
              <Globe size={13} />
              wholejourneys.com
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default ViaFrancigena;
