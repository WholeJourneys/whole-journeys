import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Landing from './pages/Landing';
import ViaFrancigena from './App';
import CoastToCoast from './pages/CoastToCoast';
import Catalonian from './pages/Catalonian';

const Router = () => (
  <BrowserRouter>
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/via-francigena" element={<ViaFrancigena />} />
      <Route path="/coast-to-coast" element={<CoastToCoast />} />
      <Route path="/catalonian" element={<Catalonian />} />
    </Routes>
  </BrowserRouter>
);

export default Router;
