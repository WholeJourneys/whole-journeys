import React from 'react';
import { Link } from 'react-router-dom';
import { Map, ArrowLeft } from 'lucide-react';

const Catalonian = () => (
  <div className="min-h-screen bg-[#fff5f5] font-sans flex flex-col items-center justify-center px-6 py-16 text-center">
    <div className="max-w-xl w-full mx-auto">
      <div className="w-16 h-16 bg-rose-100 rounded-3xl flex items-center justify-center mx-auto mb-6">
        <Map size={28} className="text-rose-600" />
      </div>
      <p className="text-xs font-black uppercase tracking-[0.3em] text-rose-600 mb-3">Coming Soon</p>
      <h1 className="text-4xl font-serif font-black text-rose-950 mb-4">Catalonian Way</h1>
      <p className="text-lg font-serif italic text-rose-800/70 mb-2">A journey through Catalonia</p>
      <p className="text-sm text-slate-500 mb-10">Catalonia, Spain · 2026</p>
      <p className="text-slate-500 mb-10 leading-relaxed">
        This itinerary is being crafted by Kathy Dragon. Check back soon — or get in touch to find out more.
      </p>
      <Link to="/" className="inline-flex items-center gap-2 text-xs font-black uppercase tracking-widest text-rose-600 hover:text-rose-900 transition-colors">
        <ArrowLeft size={14} /> Back to Infographics
      </Link>
    </div>
  </div>
);

export default Catalonian;
