import React from 'react';
import { Link } from 'react-router-dom';
import { Map, ArrowRight, Mail, Globe, Mountain } from 'lucide-react';

const itineraries = [
  {
    title: 'Via Francigena',
    subtitle: 'San Miniato to Siena',
    country: 'Italy',
    region: 'Tuscany',
    year: '2026',
    days: 6,
    km: '84.5 km',
    internal: true,
    href: '/via-francigena',
    bannerFrom: '#b45309',
    bannerTo: '#92400e',
  },
  {
    title: 'Coast to Coast',
    subtitle: "St Bees to Robin Hood's Bay",
    country: 'England',
    region: 'Northern England',
    year: '2026',
    days: 14,
    km: '190.7 mi',
    internal: false,
    href: '/coast-to-coast.pdf',
    bannerFrom: '#0f766e',
    bannerTo: '#134e4a',
  },
  {
    title: 'Catalonian Way',
    subtitle: 'A Catalan Multi-Activity Adventure',
    country: 'Spain',
    region: 'Catalonia',
    year: '2026',
    days: 5,
    km: 'TBC',
    internal: false,
    href: 'https://wholejourneys.com/catalan-adventure-preview.html',
    bannerFrom: '#1d4ed8',
    bannerTo: '#1e3a8a',
  },
];

const Card = ({ it }) => {
  const body = (
    <>
      {/* Country banner */}
      <div
        className="px-5 pt-5 pb-4 flex items-center justify-between"
        style={{ background: `linear-gradient(135deg, ${it.bannerFrom}, ${it.bannerTo})` }}
      >
        <span className="text-xs font-black uppercase tracking-[0.3em] text-white/90">
          {it.country}
        </span>
        <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center">
          <Map size={15} className="text-white" />
        </div>
      </div>

      {/* Card body */}
      <div className="p-5">
        <h2 className="text-2xl font-serif font-black text-white mb-1 leading-tight">
          {it.title}
        </h2>
        <p className="text-sm font-serif italic text-white/70 mb-1">{it.subtitle}</p>
        <p className="text-[10px] font-black uppercase tracking-widest text-white/40 mb-5">
          {it.region} · {it.year}
        </p>

        <div className="flex gap-4 text-xs font-black text-white/50 mb-4">
          <span>{it.days} Days</span>
          <span className="opacity-40">·</span>
          <span>{it.km}</span>
        </div>

        <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-widest text-white/80 group-hover:gap-3 group-hover:text-white transition-all duration-200">
          View Itinerary <ArrowRight size={12} />
        </div>
      </div>
    </>
  );

  const cardClass =
    'group block rounded-3xl overflow-hidden bg-white/10 border border-white/20 backdrop-blur-sm transition-all duration-300 hover:bg-white/15 hover:shadow-2xl hover:-translate-y-1 hover:border-white/30';

  return it.internal ? (
    <Link to={it.href} className={cardClass}>{body}</Link>
  ) : (
    <a href={it.href} target="_blank" rel="noopener noreferrer" className={cardClass}>{body}</a>
  );
};

const Landing = () => (
  <div
    className="min-h-screen font-sans flex flex-col"
    style={{ background: 'linear-gradient(160deg, #1e3a8a 0%, #0f766e 60%, #134e4a 100%)' }}
  >
    {/* Header */}
    <div className="px-6 pt-16 pb-12 text-center">
      <div className="flex items-center justify-center gap-2 mb-5">
        <Mountain size={18} className="text-white/60" />
        <span className="text-xs font-black uppercase tracking-[0.35em] text-white/60">Whole Journeys</span>
      </div>
      <h1 className="text-5xl md:text-6xl font-serif font-black text-white leading-tight mb-3">
        Infographic Itineraries
      </h1>
      <p className="text-xl font-serif italic text-white/60">designed by Kathy</p>
    </div>

    {/* Cards */}
    <div className="px-6 pb-6 max-w-5xl mx-auto w-full">
      <div className="grid md:grid-cols-3 gap-5">
        {itineraries.map((it) => <Card key={it.href} it={it} />)}
      </div>
    </div>

    {/* Footer */}
    <div className="mt-auto border-t border-white/10 px-6 pt-10 pb-12">
      <div className="max-w-5xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <p className="text-base font-serif font-black text-white mb-1">Kathy Dragon</p>
          <p className="text-sm text-white/60 font-serif italic">Whole Journeys · Infographic Itinerary Designer</p>
        </div>
        <div className="flex flex-col sm:flex-row items-center gap-5">
          <a
            href="mailto:kathy.dragon@wholejourneys.com"
            className="flex items-center gap-2 text-sm font-black uppercase tracking-wider text-white/70 hover:text-white transition-colors"
          >
            <Mail size={15} />
            kathy.dragon@wholejourneys.com
          </a>
          <a
            href="https://www.wholejourneys.com"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 text-sm font-black uppercase tracking-wider text-white/70 hover:text-white transition-colors"
          >
            <Globe size={15} />
            wholejourneys.com
          </a>
        </div>
      </div>
      <div className="max-w-5xl mx-auto mt-6 flex justify-center">
        <a
          href="https://replit.com"
          target="_blank"
          rel="noopener noreferrer"
          className="text-[11px] font-black uppercase tracking-widest text-white/30 hover:text-white/60 transition-colors"
        >
          Built with Replit
        </a>
      </div>
    </div>
  </div>
);

export default Landing;
